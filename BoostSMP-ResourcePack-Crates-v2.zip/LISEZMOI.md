BoostSMP Resource Pack - Crates Pack

Ce pack remplace visuellement les shulker boxes suivantes pour tes caisses ExcellentCrates :
- Green shulker box  -> Caisse Commune
- White shulker box  -> Caisse Vote
- Gray shulker box   -> Caisse Spawner
- Purple shulker box -> Caisse Épique
- Red shulker box    -> Caisse Légendaire

Clés incluses :
- assets/boostsmp/models/item/cle_commune.json
- assets/boostsmp/models/item/cle_vote.json
- assets/boostsmp/models/item/cle_spawner.json
- assets/boostsmp/models/item/cle_epique.json
- assets/boostsmp/models/item/cle_legendaire.json

Exemple prêt à l'emploi :
- tripwire_hook utilise CustomModelData 1001 à 1005 via assets/minecraft/items/tripwire_hook.json
  1001 = Commune
  1002 = Vote
  1003 = Spawner
  1004 = Épique
  1005 = Légendaire

Si tes clés ExcellentCrates utilisent un autre item que tripwire_hook, il faut soit :
1) copier le même système vers l'item de base voulu dans assets/minecraft/items/<item>.json
2) ou modifier la config ExcellentCrates pour donner un tripwire_hook avec le bon custom model data.

Notes :
- Ce pack change les 5 couleurs de shulker box ci-dessus partout dans le jeu.
- Il ne modifie pas les rewards ni la logique des caisses.
- Pack format prévu pour 1.21.11.
