# Resource Pack BoostSMP

Version nettoyee sans Vorath, compatible Minecraft 1.21.11.

Ce pack conserve les textures et modeles custom BoostSMP deja presents et servira de base pour ajouter les nouvelles caisses et leurs cles.

Le contenu Vorath (modeles, textures et references) a ete retire.

## Installation

Heberge le fichier ZIP sur une URL directe puis configure `server.properties` avec cette URL et le SHA1 fourni avec le fichier.
