# Resource Pack BoostSMP

Donne une vraie apparence custom (pas vanilla) aux 4 items de boost, compatible
avec le nouveau systeme d'items de Minecraft 1.21.4+ (donc ta version 1.21.11).

**Aucune modification du plugin n'est necessaire** : il utilise deja
`custom-model-data` (1001 a 1004), ce resource pack se branche dessus.

## Comment ca marche

Chaque item de boost garde son materiau vanilla de base (prismarine crystals,
amethyst shard, nether star, beacon) MAIS des que le plugin lui donne un
`custom_model_data` (ce qu'il fait deja), le resource pack detecte sa presence
et affiche a la place un modele et une texture 100% custom (gemme coloree avec
un symbole different par tier). Les autres joueurs qui trouvent un vrai
prismarine crystals/amethyst shard/nether star/beacon "normal" en jeu ne sont
PAS affectes : ils continuent de voir l'apparence vanilla classique.

## Installer le resource pack sur ton serveur

Il faut que le fichier `BoostSMP-ResourcePack.zip` soit accessible par une URL
publique pour que ton serveur puisse le proposer automatiquement aux joueurs.

### Etape 1 - Heberger le zip
Options possibles :
- Upload sur le panel de ton hebergeur (certains ont un dossier "resourcepacks"
  avec URL directe)
- Un service de fichiers statiques (ex: GitHub, un bucket, etc.)
- Si tu as deja un serveur web perso, uploade-le simplement dedans

Tu dois obtenir une URL directe vers le `.zip` (qui se termine par `.zip`,
pas une page de telechargement).

### Etape 2 - Configurer server.properties
Ajoute/modifie ces deux lignes dans `server.properties` :
```
resource-pack=https://ton-url-ici/BoostSMP-ResourcePack.zip
resource-pack-sha1=CALCULE_LE_ICI
```

Calcule le SHA1 exact du fichier que tu vas heberger (le chiffre change des
que le contenu bouge, meme legerement) :
```
sha1sum BoostSMP-ResourcePack.zip
```
(ou laisse `resource-pack-sha1=` vide, c'est optionnel mais evite un
avertissement client)

### Etape 3 - Redemarrer le serveur
Les joueurs verront une popup leur demandant d'accepter le resource pack a la
connexion.

## Alternative : combiner avec ton resource pack existant

Tu as deja des plugins (ExecutableItems, ModelEngine) qui hebergent leur
propre resource pack. Si tu preferes tout centraliser au meme endroit plutot
que d'avoir 2 popups de resource pack differentes pour les joueurs, tu peux :
1. Dezipper ce pack
2. Copier le contenu du dossier `assets/` dans le resource pack existant
   genere par ExecutableItems (fusionner les dossiers `assets/minecraft` et
   `assets/boostsmp`)
3. Re-zipper le tout

Dis-moi si tu veux de l'aide pour cette fusion.
